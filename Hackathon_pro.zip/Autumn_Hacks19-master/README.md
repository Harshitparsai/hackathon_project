# Autumn_Hacks19
This project is made for Autumn Hacks 2019. Run index.py file to experience the full version of the project.
